<!DOCTYPE html>

<?php
	// STARTING SESSION
	session_start();
	if ($_SESSION['logged_in'] != TRUE || $_SESSION['username'] != "admin") {
		header("location: ../");
	}

	include("../config.php");
	$result = mysqli_query($conn,"SELECT * FROM queue where `Status` = \"not-printed\"");
	$result_array = array();
?>

<html>

<title>Admin</title>

<head>
	<base href="../../" />
	<link rel="shortcut icon" href="style/icon1.png" />
	<meta name="description" content="website description" />
	<meta name="keywords" content="website keywords, website keywords" />
	<meta http-equiv="content-type" content="text/html; charset=windows-1252" />
	<link rel="stylesheet" type="text/css" href="style/style.css" />
	<link rel="stylesheet" type="text/css" href="ps/style.css">
	<meta name="viewport" content="width=device-width, initial-scale=1.0">
	<style>
	

    	html,body,#myChart { height:100%; width:100%;}

	.column {
	    float: left;
	    width: 50%;
	}

	/* Clear floats after the columns */
	.row:after {
	    content: "";
	    display: table;
	    clear: both;
	}

	</style>
</head>

<body>
<div id="main">
     <div id="header">
    <!------------------------------------heading----------------------------------------->
	<?php
		$include_path = "../..";
		$use_page="TRUE";
		include("$include_path/components/heading.php");
	?>
   <!---------------------------------end of heading------------------------------------->

   <!------------------------------------navigation-bar----------------------------------------->
	<?php
		include("$include_path/components/nav-bar.php");
	?>
   <!---------------------------------navigation-bar------------------------------------->

	</div> <!-- header ends here --> 
   <div id="site_content">
       
	<h2> Welcome Admin! </h2>
	<div class="row">
		<div class="column"> 
			<form action="" method="post">	
			Select Stream : 
			<select name="stream">
				<option value="mcme">Int. M Tech</option> 
				<option value="mcmt">M Tech</option>
			</select> <br>
			<br>   	
			<input type="submit" value="Submit" name="stream">	
			</form>
		</div>

		<div class="column">  
			<form action="" method="post">	
			Select Time Range: 
			<select name="range" onchange="showfield(this.options[this.selectedIndex].value)" id="otherDiv">
				<option value="monthly">Monthly</option> 
				<option value="custom">Custom</option>
			</select> <br>
			<br>   	
			<input type="submit" value="Submit" name="time">	
			</form>
			<div id="otherDiv"> </div> <br>
		</p>
		</div>
	</div>

	<script type="text/javascript">
		function showfield(name) {
			if (name=='custom')
				document.getElementById('otherDiv').innerHTML='Please choose the start date<input type="date" name="range"/>';
		  	else
				document.getElementById('otherDiv').innerHTML='';
		}
	</script>

	<?php 
		if ($_SERVER['REQUEST_METHOD'] == 'POST') {
			isset($_POST['stream']) {
				$stream = $_POST['stream'];
			}
			isset($_POST['time']) {
				$time_op = $_POST['time'];			
			}
		}
	?>
    </div><!-- site_content ends here -->
    <!------------------------------------footer----------------------------------->
	<?php
		include("$include_path/components/footer.php");
	?>
    <!---------------------------------footer------------------------------------->

  </div><!-- main ends here -->
</body>
</html>

