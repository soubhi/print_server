<?php


if(isset($_GET['val']) && !empty($_GET['val'])){

			$stream = $_GET["val"];
			echo "\nStream = $stream\n";
			/*$time = $_POST["time"];
			echo "\nTime Range = $time\n<br>";
			*/
	

			/*if($time == 'monthly') {
				
			}*/
				//Monthly($stream, $conn);

		}

?>
