<!DOCTYPE html>

<?php
	// STARTING SESSION
	session_start();
	if ($_SESSION['logged_in'] != TRUE || $_SESSION['username'] != "admin") {
		header("location: ../");
	}

	include("../config.php");
	$result = mysqli_query($conn,"SELECT * FROM queue where `Status` = \"not-printed\"");
	$result_array = array();
?>

<html>

<title>Admin</title>

<head>
	<base href="../../" />
	<link rel="shortcut icon" href="style/icon1.png" />
	<meta name="description" content="website description" />
	<meta name="keywords" content="website keywords, website keywords" />
	<meta http-equiv="content-type" content="text/html; charset=windows-1252" />
	<link rel="stylesheet" type="text/css" href="style/style.css" />
	<link rel="stylesheet" type="text/css" href="ps/style.css">
	<meta name="viewport" content="width=device-width, initial-scale=1.0">
	<style>
	

    	html,body,#myChart { height:100%; width:100%;}

	</style>
</head>

<body>
<div id="main">
     <div id="header">
    <!------------------------------------heading----------------------------------------->
	<?php
		$include_path = "../..";
		$use_page="TRUE";
		include("$include_path/components/heading.php");
	?>
   <!---------------------------------end of heading------------------------------------->

   <!------------------------------------navigation-bar----------------------------------------->
	<?php
		include("$include_path/components/nav-bar.php");
	?>
   <!---------------------------------navigation-bar------------------------------------->

	</div> <!-- header ends here --> 
   <div id="site_content">
       
	<h2> Welcome Admin! </h2>
	 <div class="admin-box"> 
		<div class="logout" style="float:right"><a href="ps/logout.php">logout</a></div> <br>
		<a href="ps/admin/admin.php" class="home-button "style="background-color: grey;">&laquo; Home</a>
		<a href="ps/admin/change_quota.php" class="nav-btn">Change Quota</a>
		<a href="ps/admin/history.php" class="nav-btn" >View History</a>
		<a href="ps/admin/stats.php" class="nav-btn" style="background-color: lightblue; color: white;">Statistics</a>
	
		<?php
		shell_exec("ls");
		exec("ls",$o);
		print_r($o);
		echo exec("pwd");	
		exec("gnuplot myplot.gp", $o, $v);
		echo $v;
		?>

		<?php
		$result = mysqli_query($conn,"SELECT CAST(Uploaded_Time as DATE) as date, count(*) as count FROM `queue_test` where Uploaded_Time>='2018-01-01 06:42:10' and Uploaded_Time<='2018-12-06 07:42:50' group by CAST(Uploaded_Time as DATE) ;");
		$rows = $result->fetchAssoc();
		//Setup the filename that our CSV will have when it is downloaded.
		$fileName = 'ps/admin/range.csv';
		 
		//Open up a file pointer
		$fp = fopen($filename, 'w');
			 
		//Then, loop through the rows and write them to the CSV file.
		foreach ($rows as $row) {
		   	echo $row;
		}
		?>
		<img src="ps/admin/figure.png" >
	</div>

    </div><!-- site_content ends here -->
    <!------------------------------------footer----------------------------------------->
	<?php
		include("$include_path/components/footer.php");
	?>
    <!---------------------------------footer------------------------------------->

  </div><!-- main ends here -->
</body>
</html>

<!--- chown www-data admin/ --->  


